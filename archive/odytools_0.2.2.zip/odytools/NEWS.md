# odytools 0.1.0

* Added ody_summarise_df
* Added ody_define_timepoints
* Added ody_pdx_model_sensitivity

# odytools 0.2.0

* Added data quality functions ody_verify_completeness and ody_verify_conformance.
* Added ody_render_quality_report to render a html with the result of ody_verify_completeness and ody_verify_conformance.

# odytools 0.2.1

* Added entry controls to ody_pdx_model_sensitivity.

# odytools 0.2.2

* Now ody_pdx_model_sensitivity also works with a 3 levels treatment factor.
